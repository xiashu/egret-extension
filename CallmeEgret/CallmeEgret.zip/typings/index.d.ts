/// <reference path="../node_modules/egretwing/typings/index.d.ts" />
